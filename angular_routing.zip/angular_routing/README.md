# AngularUi

![image](https://user-images.githubusercontent.com/29041340/190986104-a7db4391-5bf2-41a9-a6b2-5763a0523a3f.png)
![image](https://user-images.githubusercontent.com/29041340/190986236-c146cb7b-9066-4f6b-a822-011d4320aa6d.png)
![image](https://user-images.githubusercontent.com/29041340/190986296-ff218aa7-5120-4c4e-b9ca-32ba9c1bab45.png)
![image](https://user-images.githubusercontent.com/29041340/190986357-494f2c95-edaf-4201-bb8a-1d97ee847152.png)
![image](https://user-images.githubusercontent.com/29041340/190986413-f1b8b1b6-23c2-4437-a951-3252ac57801a.png)


This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 14.2.3.

## Development server

Run `ng serve` for a dev server. Navigate to `http://localhost:4200/`. The application will automatically reload if you change any of the source files.

## Code scaffolding

Run `ng generate component component-name` to generate a new component. You can also use `ng generate directive|pipe|service|class|guard|interface|enum|module`.

## Build

Run `ng build` to build the project. The build artifacts will be stored in the `dist/` directory.

## Running unit tests

Run `ng test` to execute the unit tests via [Karma](https://karma-runner.github.io).

## Running end-to-end tests

Run `ng e2e` to execute the end-to-end tests via a platform of your choice. To use this command, you need to first add a package that implements end-to-end testing capabilities.

## Further help

To get more help on the Angular CLI use `ng help` or go check out the [Angular CLI Overview and Command Reference](https://angular.io/cli) page.
